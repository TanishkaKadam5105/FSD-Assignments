const productContainer = document.getElementById("products");

fetch("/products")
  .then(res => res.json())
  .then(data => {
    productContainer.innerHTML = "";

    data.forEach(product => {
      const div = document.createElement("div");
      div.className = "card";

      div.innerHTML = `
        <img src="${product.image}" />
        <h3>${product.name}</h3>
        <p>₹${product.price}</p>
        <button onclick="addToCart('${product.name}', ${product.price})">
          Add to Cart
        </button>
      `;

      productContainer.appendChild(div);
    });
  });

function addToCart(name, price) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  cart.push({ name, price });

  localStorage.setItem("cart", JSON.stringify(cart));

  alert(name + " added to cart!");
}