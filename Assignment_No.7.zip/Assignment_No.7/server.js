const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());
app.use(express.static("public"));

mongoose.connect("mongodb://127.0.0.1:27017/shopease")
.then(() => console.log("MongoDB Connected"));

const Product = require("./models/Product");

// 👉 Auto insert products if empty
app.get("/seed", async (req, res) => {
  await Product.deleteMany();

  await Product.insertMany([
    {
      name: "Vitamin C Serum",
      price: 599,
      image: "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519"
    },
    {
      name: "Face Wash",
      price: 299,
      image: "https://images.unsplash.com/photo-1585238342028-4e1f5d4c9f7d"
    },
    {
      name: "Moisturizer",
      price: 499,
      image: "https://images.unsplash.com/photo-1596755389378-c31d21fd1273"
    },
    {
      name: "Hair Serum",
      price: 399,
      image: "https://images.unsplash.com/photo-1611930022073-b7a4ba5fcccd"
    }
  ]);

  res.send("Products Inserted");
});

// GET products
app.get("/products", async (req, res) => {
  const products = await Product.find();
  res.json(products);
});

app.listen(5000, () => {
  console.log("Server running at http://localhost:5000");
});